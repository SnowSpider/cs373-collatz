Course Name: CS w373
Unique: 84270
First Name: Wonjun
Last Name: Lee
EID: WL4337
CS Username: wlee
GitHub ID: SnowSpider
GitHub Repository Name: cs373-collatz
Estimated number of hours: 6
Actual    number of hours: 10
Comments: 

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
